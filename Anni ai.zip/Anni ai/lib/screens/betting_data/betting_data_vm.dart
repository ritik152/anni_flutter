import 'package:anni_ai/apis/api_controller.dart';

import 'all_teams_model.dart';
import 'betting_data_model.dart';

class BettingDataVm {

  List<BettingDataModel> bettingData = [];
  var value = week;
  var isLoading = true;

}