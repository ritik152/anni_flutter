
class Strings{

  static var appName = "Rapido";

}