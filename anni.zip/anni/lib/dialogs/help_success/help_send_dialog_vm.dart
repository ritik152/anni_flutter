import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';


class HelpSuccessDialogVM{


  void noClick(BuildContext context) {
    Navigator.pop(context);
  }

}