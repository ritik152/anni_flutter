class PlayerDataVm {

  var overview = true;
  var table = false;
  var graph = false;
  var roster = false;
  var career = false;

}